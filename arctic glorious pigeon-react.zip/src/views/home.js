import React, { Fragment } from 'react'

import { Helmet } from 'react-helmet'

import Navbar8 from '../components/navbar8'
import Hero17 from '../components/hero17'
import Features24 from '../components/features24'
import CTA26 from '../components/cta26'
import Features25 from '../components/features25'
import Pricing14 from '../components/pricing14'
import Steps2 from '../components/steps2'
import Testimonial17 from '../components/testimonial17'
import Contact10 from '../components/contact10'
import Footer4 from '../components/footer4'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Arctic Glorious Pigeon</title>
        <meta property="og:title" content="Arctic Glorious Pigeon" />
      </Helmet>
      <Navbar8
        page4Description={
          <Fragment>
            <span className="home-text100">Get in touch with us</span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="home-text101">Sign In</span>
          </Fragment>
        }
        link2={
          <Fragment>
            <span className="home-text102">/courses</span>
          </Fragment>
        }
        page1={
          <Fragment>
            <span className="home-text103">Home</span>
          </Fragment>
        }
        link1={
          <Fragment>
            <span className="home-text104">/home</span>
          </Fragment>
        }
        page4={
          <Fragment>
            <span className="home-text105">Contact</span>
          </Fragment>
        }
        page2={
          <Fragment>
            <span className="home-text106">Courses</span>
          </Fragment>
        }
        link4={
          <Fragment>
            <span className="home-text107">/contact</span>
          </Fragment>
        }
        page1Description={
          <Fragment>
            <span className="home-text108">Explore our featured courses</span>
          </Fragment>
        }
        page2Description={
          <Fragment>
            <span className="home-text109">
              Discover a wide range of courses
            </span>
          </Fragment>
        }
        link3={
          <Fragment>
            <span className="home-text110">/about</span>
          </Fragment>
        }
        page3={
          <Fragment>
            <span className="home-text111">About Us</span>
          </Fragment>
        }
        page3Description={
          <Fragment>
            <span className="home-text112">Learn more about our platform</span>
          </Fragment>
        }
        action2={
          <Fragment>
            <span className="home-text113">Sign Up</span>
          </Fragment>
        }
      ></Navbar8>
      <Hero17
        action2={
          <Fragment>
            <span className="home-text114">Secondary action</span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="home-text115">Main action</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text116">
              Unlock Your Potential with Online Courses
            </span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text117">
              Take your skills to the next level with our wide range of online
              courses. Learn from industry experts and achieve your goals at
              your own pace.
            </span>
          </Fragment>
        }
      ></Hero17>
      <Features24
        feature3Description={
          <Fragment>
            <span className="home-text118">
              Engage with interactive course materials and quizzes
            </span>
          </Fragment>
        }
        feature3Title={
          <Fragment>
            <span className="home-text119">Interactive Learning</span>
          </Fragment>
        }
        feature2Description={
          <Fragment>
            <span className="home-text120">
              Access courses anytime, anywhere on any device
            </span>
          </Fragment>
        }
        feature1Title={
          <Fragment>
            <span className="home-text121">Diverse Course Selection</span>
          </Fragment>
        }
        feature1Description={
          <Fragment>
            <span className="home-text122">
              Choose from a wide range of courses taught by industry experts
            </span>
          </Fragment>
        }
        feature2Title={
          <Fragment>
            <span className="home-text123">Flexible Learning</span>
          </Fragment>
        }
      ></Features24>
      <CTA26
        heading1={
          <Fragment>
            <span className="home-text124">Start learning today!</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text125">
              Browse our wide range of courses and take the next step in your
              education journey.
            </span>
          </Fragment>
        }
        action1={
          <Fragment>
            <span className="home-text126">Explore Courses</span>
          </Fragment>
        }
      ></CTA26>
      <Features25
        feature3Description={
          <Fragment>
            <span className="home-text127">
              Learn from industry experts and professionals in their respective
              fields.
            </span>
          </Fragment>
        }
        feature1Description={
          <Fragment>
            <span className="home-text128">
              Choose from a variety of courses covering different subjects and
              skill levels.
            </span>
          </Fragment>
        }
        feature2Title={
          <Fragment>
            <span className="home-text129">Flexible Learning Options</span>
          </Fragment>
        }
        feature1Title={
          <Fragment>
            <span className="home-text130">Wide Range of Courses</span>
          </Fragment>
        }
        feature2Description={
          <Fragment>
            <span className="home-text131">
              Study at your own pace with our flexible online learning platform.
            </span>
          </Fragment>
        }
        feature3Title={
          <Fragment>
            <span className="home-text132">Expert Instructors</span>
          </Fragment>
        }
      ></Features25>
      <Pricing14
        plan3Price={
          <Fragment>
            <span className="home-text133">$79.99</span>
          </Fragment>
        }
        plan3Action={
          <Fragment>
            <span className="home-text134">Enroll Now</span>
          </Fragment>
        }
        plan11={
          <Fragment>
            <span className="home-text135">Basic plan</span>
          </Fragment>
        }
        plan1Action={
          <Fragment>
            <span className="home-text136">Enroll Now</span>
          </Fragment>
        }
        plan31={
          <Fragment>
            <span className="home-text137">Enterprise plan</span>
          </Fragment>
        }
        plan3Feature41={
          <Fragment>
            <span className="home-text138">Feature text goes here</span>
          </Fragment>
        }
        plan1Feature2={
          <Fragment>
            <span className="home-text139">Certificate of completion</span>
          </Fragment>
        }
        plan2Feature11={
          <Fragment>
            <span className="home-text140">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature51={
          <Fragment>
            <span className="home-text141">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature41={
          <Fragment>
            <span className="home-text142">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature2={
          <Fragment>
            <span className="home-text143">Priority customer support</span>
          </Fragment>
        }
        plan3Feature21={
          <Fragment>
            <span className="home-text144">Feature text goes here</span>
          </Fragment>
        }
        plan2Feature4={
          <Fragment>
            <span className="home-text145">Feature text goes here</span>
          </Fragment>
        }
        plan2Yearly={
          <Fragment>
            <span className="home-text146">$499.99</span>
          </Fragment>
        }
        plan1Action1={
          <Fragment>
            <span className="home-text147">Get started</span>
          </Fragment>
        }
        plan2Action={
          <Fragment>
            <span className="home-text148">Enroll Now</span>
          </Fragment>
        }
        plan3Feature1={
          <Fragment>
            <span className="home-text149">Access to unlimited courses</span>
          </Fragment>
        }
        plan2Feature3={
          <Fragment>
            <span className="home-text150">Quizzes and assignments</span>
          </Fragment>
        }
        plan1Price1={
          <Fragment>
            <span className="home-text151">$200/yr</span>
          </Fragment>
        }
        plan2={
          <Fragment>
            <span className="home-text152">Business plan</span>
          </Fragment>
        }
        plan2Feature21={
          <Fragment>
            <span className="home-text153">Feature text goes here</span>
          </Fragment>
        }
        plan2Action1={
          <Fragment>
            <span className="home-text154">Get started</span>
          </Fragment>
        }
        plan3Feature2={
          <Fragment>
            <span className="home-text155">Personalized learning path</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text156">
              Choose the perfect plan for you
            </span>
          </Fragment>
        }
        plan2Feature1={
          <Fragment>
            <span className="home-text157">Access to 20 courses</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text158">Pricing plan</span>
          </Fragment>
        }
        plan3Feature31={
          <Fragment>
            <span className="home-text159">Feature text goes here</span>
          </Fragment>
        }
        plan1={
          <Fragment>
            <span className="home-text160">Basic plan</span>
          </Fragment>
        }
        plan21={
          <Fragment>
            <span className="home-text161">Business plan</span>
          </Fragment>
        }
        plan1Feature11={
          <Fragment>
            <span className="home-text162">Feature text goes here</span>
          </Fragment>
        }
        plan1Feature21={
          <Fragment>
            <span className="home-text163">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature5={
          <Fragment>
            <span className="home-text164">Feature text goes here</span>
          </Fragment>
        }
        plan2Yearly1={
          <Fragment>
            <span className="home-text165">or $29 monthly</span>
          </Fragment>
        }
        plan2Price={
          <Fragment>
            <span className="home-text166">$49.99</span>
          </Fragment>
        }
        plan3Yearly1={
          <Fragment>
            <span className="home-text167">or $49 monthly</span>
          </Fragment>
        }
        plan2Feature31={
          <Fragment>
            <span className="home-text168">Feature text goes here</span>
          </Fragment>
        }
        plan3Feature11={
          <Fragment>
            <span className="home-text169">Feature text goes here</span>
          </Fragment>
        }
        plan1Yearly1={
          <Fragment>
            <span className="home-text170">or $20 monthly</span>
          </Fragment>
        }
        plan2Price1={
          <Fragment>
            <span className="home-text171">$299/yr</span>
          </Fragment>
        }
        plan3Yearly={
          <Fragment>
            <span className="home-text172">$799.99</span>
          </Fragment>
        }
        plan3Feature4={
          <Fragment>
            <span className="home-text173">Feature text goes here</span>
          </Fragment>
        }
        plan3Price1={
          <Fragment>
            <span className="home-text174">$499/yr</span>
          </Fragment>
        }
        plan1Feature31={
          <Fragment>
            <span className="home-text175">Feature text goes here</span>
          </Fragment>
        }
        plan1Feature3={
          <Fragment>
            <span className="home-text176">
              Lifetime access to course materials
            </span>
          </Fragment>
        }
        plan1Yearly={
          <Fragment>
            <span className="home-text177">$299.99</span>
          </Fragment>
        }
        plan1Feature1={
          <Fragment>
            <span className="home-text178">Access to 10 courses</span>
          </Fragment>
        }
        plan3Feature3={
          <Fragment>
            <span className="home-text179">One-on-one coaching sessions</span>
          </Fragment>
        }
        content2={
          <Fragment>
            <span className="home-text180">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
          </Fragment>
        }
        plan3Action1={
          <Fragment>
            <span className="home-text181">Get started</span>
          </Fragment>
        }
        plan1Price={
          <Fragment>
            <span className="home-text182">$29.99</span>
          </Fragment>
        }
        plan3={
          <Fragment>
            <span className="home-text183">Enterprise plan</span>
          </Fragment>
        }
      ></Pricing14>
      <Steps2
        step1Description={
          <Fragment>
            <span className="home-text184">
              Explore our wide range of courses covering various topics and
              skills.
            </span>
          </Fragment>
        }
        step3Description={
          <Fragment>
            <span className="home-text185">
              Enroll in the course of your choice and securely make the payment.
            </span>
          </Fragment>
        }
        step2Title={
          <Fragment>
            <span className="home-text186">Select Course</span>
          </Fragment>
        }
        step2Description={
          <Fragment>
            <span className="home-text187">
              Choose the course that best fits your needs and interests.
            </span>
          </Fragment>
        }
        step1Title={
          <Fragment>
            <span className="home-text188">Browse Courses</span>
          </Fragment>
        }
        step3Title={
          <Fragment>
            <span className="home-text189">Enroll and Pay</span>
          </Fragment>
        }
        step4Description={
          <Fragment>
            <span className="home-text190">
              Begin your learning journey with high-quality content and
              interactive lessons.
            </span>
          </Fragment>
        }
        step4Title={
          <Fragment>
            <span className="home-text191">Start Learning</span>
          </Fragment>
        }
      ></Steps2>
      <Testimonial17
        author2Position={
          <Fragment>
            <span className="home-text192">Marketing Manager, XYZ Corp.</span>
          </Fragment>
        }
        author1Position={
          <Fragment>
            <span className="home-text193">CEO, ABC Inc.</span>
          </Fragment>
        }
        author1Name={
          <Fragment>
            <span className="home-text194">John Doe</span>
          </Fragment>
        }
        author3Name={
          <Fragment>
            <span className="home-text195">David Johnson</span>
          </Fragment>
        }
        review2={
          <Fragment>
            <span className="home-text196">Great learning experience!</span>
          </Fragment>
        }
        author2Name={
          <Fragment>
            <span className="home-text197">Jane Smith</span>
          </Fragment>
        }
        author4Position={
          <Fragment>
            <span className="home-text198">Student</span>
          </Fragment>
        }
        author4Name={
          <Fragment>
            <span className="home-text199">Sarah Lee</span>
          </Fragment>
        }
        content1={
          <Fragment>
            <span className="home-text200">
              I have taken multiple courses from this platform and each one has
              exceeded my expectations. The instructors are knowledgeable and
              the content is top-notch.
            </span>
          </Fragment>
        }
        author3Position={
          <Fragment>
            <span className="home-text201">Freelancer</span>
          </Fragment>
        }
        review1={
          <Fragment>
            <span className="home-text202">Highly recommend!</span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text203">Testimonials</span>
          </Fragment>
        }
        review3={
          <Fragment>
            <span className="home-text204">Fantastic courses!</span>
          </Fragment>
        }
        review4={
          <Fragment>
            <span className="home-text205">Best value for money!</span>
          </Fragment>
        }
      ></Testimonial17>
      <Contact10
        content1={
          <Fragment>
            <span className="home-text206">
              Have a question or need support? Feel free to reach out to us.
            </span>
          </Fragment>
        }
        location1Description={
          <Fragment>
            <span className="home-text207">
              Send us an email and we&apos;ll get back to you as soon as
              possible.
            </span>
          </Fragment>
        }
        heading1={
          <Fragment>
            <span className="home-text208">Contact Us</span>
          </Fragment>
        }
        location2Description={
          <Fragment>
            <span className="home-text209">
              Give us a call during our office hours for immediate assistance.
            </span>
          </Fragment>
        }
        location1={
          <Fragment>
            <span className="home-text210">Email: info@website.com</span>
          </Fragment>
        }
        location2={
          <Fragment>
            <span className="home-text211">Phone: +1234567890</span>
          </Fragment>
        }
      ></Contact10>
      <Footer4
        link5={
          <Fragment>
            <span className="home-text212">Blog</span>
          </Fragment>
        }
        link3={
          <Fragment>
            <span className="home-text213">Contact Us</span>
          </Fragment>
        }
        link1={
          <Fragment>
            <span className="home-text214">Courses</span>
          </Fragment>
        }
        termsLink={
          <Fragment>
            <span className="home-text215">Terms and Conditions</span>
          </Fragment>
        }
        link2={
          <Fragment>
            <span className="home-text216">About Us</span>
          </Fragment>
        }
        link4={
          <Fragment>
            <span className="home-text217">FAQs</span>
          </Fragment>
        }
        cookiesLink={
          <Fragment>
            <span className="home-text218">Cookies Policy</span>
          </Fragment>
        }
        privacyLink={
          <Fragment>
            <span className="home-text219">Privacy Policy</span>
          </Fragment>
        }
      ></Footer4>
    </div>
  )
}

export default Home
